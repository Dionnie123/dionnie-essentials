<?php

if (!defined('WPINC')) {
    die;
}
require_once('dist/lib/helpers.php');
require_once('dist/lib/enqueue-assets.php');
include_once('dist/lib/books.php');
